
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Participant {
    
	Connection con=null;
	Statement pstmt=null;
	static  int id;
	static  String name;
	static String email;
	static String phone_number;
	/*
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the operations");
		System.out.println("1.Add a new participant");
		System.out.println("2.view participant details");
		System.out.println("3.Update participant information");
		System.out.println("4.Delete a participant");
		int operations=sc.nextInt();
		
		switch(operations) {
		
		case 1:
			addParticipant();
			break;
		case 2:
			viewParticipantDetails();
			break;
		case 3:
			updateParticipantInfo();
			break;
		case 4:
			deleteParticipant();
			break;
		}
	}
	*/
      public static void addParticipant() {

    		 /* sc1-->for integer type*/
    		 Scanner sc1=new Scanner(System.in);
    		 
    		 /* sc2-->for String type*/
    		 Scanner sc2=new Scanner(System.in);
    		 
    		 System.out.println("Enter id");
    		  id=sc1.nextInt();
    		 
    		 System.out.println("Enter Name");
    	     name=sc2.next();
    		 
    		 sc2.nextLine();
    		 System.out.println("Enter email");
    		 email=sc2.nextLine();
    		 
    		 System.out.println("Enter phone_number");
    		 phone_number=sc2.next();
    		 
    		 
    		 Connection con=null;
    		 PreparedStatement pstmt=null;
    		 
    		 String q="insert into participant_table(participant_id,participant_name,participant_email,participant_phone_number) values(?,?,?,?)";
    		 
    		 
    		 try {
    			con=MyConnect.connect();
    			pstmt=con.prepareStatement(q);
    			pstmt.setInt(1,id);
    			pstmt.setString(2,name);
    			pstmt.setString(3,email);
    			pstmt.setString(4,phone_number);
    			
    			
    			int x=pstmt.executeUpdate();
    			//System.out.println("Output"+" "+x);
    			if(x!=0) {
    				System.out.println("Data is inserted");
    			}
    			else {
    				System.out.println("Data is not inserted");
    			}
    			
    			
    		} catch (ClassNotFoundException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		} catch (SQLException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}
    		
    		 
    		finally {
    			
    				try {
    					MyConnect.close1( pstmt, con);
    				} catch (Exception e) {
    					// TODO Auto-generated catch block
    					e.printStackTrace();
    				}
    			 
    		
    		}
      }
      
      public static void viewParticipantDetails() {
  		Connection con=null;
  		Statement stmt=null;
  		ResultSet res=null;
  		
  		 try{
  			    con= MyConnect.connect();
  				stmt=con.createStatement();
  				res=stmt.executeQuery("select* from participant_table");
  				while(res.next()==true) {
  				System.out.println(res.getInt(1)+" "+res.getString(2)+" "+
  				 res.getString(3)+" "+res.getString(4));	
  				 }
  				
  			 }
  			 catch(ClassNotFoundException  | SQLException e ){
  			 e.printStackTrace();
  			 }
  		 finally {
  			 
  			 MyConnect.close2(res, stmt, con);
  		 }
  			
  		
  	}
      
      public static void deleteParticipant() {
  		
  		Scanner sc1=new Scanner(System.in);
  		
  		System.out.println("Enter the id to be deleted");
  		id=sc1.nextInt();
  		
  		 Connection con=null;
  		 PreparedStatement pstmt=null;
  		 
  		 String q="delete from participant_table where participant_id=?";
  		
  		 try {
  				con=MyConnect.connect();
  				pstmt=con.prepareStatement(q);
  				pstmt.setInt(1,id);
  				
  		         
  				int x=pstmt.executeUpdate();
  				//System.out.println("Output"+" "+x);
  				if(x!=0) {
  					System.out.println("Data Deleted");
  					
  				}
  				else {
  					System.out.println("Failure in deletion");
  				}
  	        }
  		 catch (ClassNotFoundException e) {
  				// TODO Auto-generated catch block
  				e.printStackTrace();
  			} catch (SQLException e) {
  				// TODO Auto-generated catch block
  				e.printStackTrace();
  			}
  		 finally {
  			 try {
  					MyConnect.close1( pstmt, con);
  				} catch (Exception e) { 
  					// TODO Auto-generated catch block
  					e.printStackTrace();
  				}
  			 
  		 }
  	
  }
      public static void updateParticipantInfo() {
    		
    	    Scanner sc1=new Scanner(System.in);
    	    Scanner sc2=new Scanner(System.in);
    			
    	        System.out.println("Enter the data to be updated");
    	        id=sc1.nextInt();
    			System.out.println("Enter the name to be updated");
    			name=sc2.nextLine();
    			System.out.println("Enter the email to be updated");
    			email=sc2.nextLine();
    			System.out.println("Enter the phone_number to be updated");
    			phone_number= sc1.next();
    			
    			
    			 Connection con=null;
    			 PreparedStatement pstmt=null;
    			 
    			 String q="update participant_table set participant_name=?, participant_phone_number=? ,participant_email=? where participant_id=?";
    			
    			 try {
    					con=MyConnect.connect();
    					pstmt=con.prepareStatement(q);
    					
                        
    					
    					pstmt.setString(2, phone_number);
    					pstmt.setString(1, name);
    					pstmt.setString(3,email);

    					pstmt.setInt(4, id);
    					
    					
    			         
    					int x=pstmt.executeUpdate();
    					//System.out.println("Output"+" "+x);
    					if(x!=0) {
    						System.out.println("Data updated");
    					}
    					else {
    						System.out.println("Data is not updated");
    					}
    		        }
    			 catch (ClassNotFoundException e) {
    					// TODO Auto-generated catch block
    					e.printStackTrace();
    				} catch (SQLException e) {
    					// TODO Auto-generated catch block
    					e.printStackTrace();
    				}
    			 finally {
    				 try {
    						MyConnect.close1( pstmt, con);
    					} catch (Exception e) { 
    						// TODO Auto-generated catch block
    						e.printStackTrace();
    					}
    				 
    			 }
    		}
      
      
      
      
      
      
      
      
      
      
	}


