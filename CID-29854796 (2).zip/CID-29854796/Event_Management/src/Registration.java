

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
public class Registration {
       
	Connection con=null;
	Statement pstmt=null;
	static int registration_id ;
    static int event_id ;
    static int participant_id;
    static int registration_date;
    static String status ;
    
	/*public static void main(String[] args) {
        
        Scanner sc=new Scanner(System.in);
		System.out.println("Enter the operations");
		System.out.println("1.Register a participant for an event");
		System.out.println("2.View registration details");
		System.out.println("3.Update registration information");
		System.out.println("4.Cancel a registration");
		int operations=sc.nextInt();
		
		switch(operations) {
		
		case 1:
			registerParticipant();
			break;
		case 2:
			viewRegistrationDetails();
			break;
		case 3:
			updateRegistrationInfo();
			break;
		case 4:
			cancelRegistration();
			break;
		}
	}*/
	
	public static void registerParticipant() {

		 /* sc1-->for integer type*/
		 Scanner sc1=new Scanner(System.in);
		 
		 /* sc2-->for String type*/
		 Scanner sc2=new Scanner(System.in);
		 
		 System.out.println("Enter registration_id");
		  registration_id =sc1.nextInt();
		 
		 System.out.println("Enter event_id");
		  event_id=sc1.nextInt();
		 
		 sc1.nextLine();
		 System.out.println("Enter participant_id");
		  participant_id=sc1.nextInt();
		 
		 System.out.println("Enter registration_date");
		  registration_date=sc1.nextInt();
		 
		 System.out.println("Enter the status");
		 String status = sc2.next();
		 
		 
		 Connection con=null;
		 PreparedStatement pstmt=null;
		 
		 String q="insert into registration_table(registration_id,event_id,participant_id,registration_date,status) values(?,?,?,?,?)";
		 
		 
		 try {
			con=MyConnect.connect();
			pstmt=con.prepareStatement(q);
			pstmt.setInt(1,registration_id);
			pstmt.setInt(2,event_id);
			pstmt.setInt(3,participant_id);
			pstmt.setInt(4,registration_date);
			pstmt.setString(5,status);
			
			
			int x=pstmt.executeUpdate();
			//System.out.println("Output"+" "+x);
			if(x!=0) {
				System.out.println("Data is inserted");
			}
			else {
				System.out.println("Data is not inserted");
			}
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		 
		finally {
			
				try {
					MyConnect.close1( pstmt, con);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			 
		
		}

	}
	
	 public static void viewRegistrationDetails() {
	  		Connection con=null;
	  		Statement stmt=null;
	  		ResultSet res=null;
	  		
	  		 try{
	  			    con= MyConnect.connect();
	  				stmt=con.createStatement();
	  				res=stmt.executeQuery("select* from registration_table");
	  				while(res.next()==true) {
	  				System.out.println(res.getInt(1)+" "+res.getInt(2)+" "+
	  				 res.getInt(3)+" "+res.getDate(4)+" "+res.getString(5));	
	  				 }
	  				
	  			 }
	  			 catch(ClassNotFoundException  | SQLException e ){
	  			 e.printStackTrace();
	  			 }
	  		 finally {
	  			 
	  			 MyConnect.close2(res, stmt, con);
	  		 }
	  			
	  		
	  	}
	
	
	 public static void cancelRegistration() {
	  		
	  		Scanner sc1=new Scanner(System.in);
	  		
	  		System.out.println("Enter the id to be deleted");
	  		registration_id=sc1.nextInt();
	  		
	  		 Connection con=null;
	  		 PreparedStatement pstmt=null;
	  		 
	  		 String q="delete from registration_table where registration_id=?";
	  		
	  		 try {
	  				con=MyConnect.connect();
	  				pstmt=con.prepareStatement(q);
	  				pstmt.setInt(1,registration_id);
	  				
	  		         
	  				int x=pstmt.executeUpdate();
	  				//System.out.println("Output"+" "+x);
	  				if(x!=0) {
	  					System.out.println("Data Deleted");
	  					
	  				}
	  				else {
	  					System.out.println("Failure in deletion");
	  				}
	  	        }
	  		 catch (ClassNotFoundException e) {
	  				// TODO Auto-generated catch block
	  				e.printStackTrace();
	  			} catch (SQLException e) {
	  				// TODO Auto-generated catch block
	  				e.printStackTrace();
	  			}
	  		 finally {
	  			 try {
	  					MyConnect.close1( pstmt, con);
	  				} catch (Exception e) { 
	  					// TODO Auto-generated catch block
	  					e.printStackTrace();
	  				}
	  			 
	  		 }
	  	
	  }
	 
	 public static void updateRegistrationInfo() {
 		
 	    Scanner sc1=new Scanner(System.in);
 	    Scanner sc2=new Scanner(System.in);
 			
 	        System.out.println("Enter the data to be updated");
 	        registration_id=sc1.nextInt();
 			System.out.println("Enter the column to be updated");
 			status=sc2.nextLine();
 			
 			
 			
 			 Connection con=null;
 			 PreparedStatement pstmt=null;
 			 
 			 String q="update registration_table set status=? where registration_id=?";
 			
 			 try {
 					con=MyConnect.connect();
 					pstmt=con.prepareStatement(q);
 					
 					pstmt.setString(1, status);
 					pstmt.setInt(2, registration_id);
 					
 					
 			         
 					int x=pstmt.executeUpdate();
 					//System.out.println("Output"+" "+x);
 					if(x!=0) {
 						System.out.println("Data updated");
 					}
 					else {
 						System.out.println("Data is not updated");
 					}
 		        }
 			 catch (ClassNotFoundException e) {
 					// TODO Auto-generated catch block
 					e.printStackTrace();
 				} catch (SQLException e) {
 					// TODO Auto-generated catch block
 					e.printStackTrace();
 				}
 			 finally {
 				 try {
 						MyConnect.close1( pstmt, con);
 					} catch (Exception e) { 
 						// TODO Auto-generated catch block
 						e.printStackTrace();
 					}
 				 
 			 }
 		}
   
	
	
}


