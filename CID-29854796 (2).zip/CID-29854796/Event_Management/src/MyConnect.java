import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class MyConnect {
    
	
	static String url="jdbc:mysql://localhost:3306/eventmanagement";
	static String username="root";
	static String password="amrish1911";
	
	static Connection con=null;;
	static Connection connect() throws ClassNotFoundException, SQLException {
		 
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection(url,username,password);
			return con;	

	}
	
		
	
	public static void close2(ResultSet res, Statement stmt, Connection con2) 
		// TODO Auto-generated method stub
		{
			try {
				if(res!=null)
				   res.close();
				
				if(stmt!=null)
				   stmt.close();
				
				if(con!=null)
				   con.close();
				
			} 
		
			catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	public static void close1(PreparedStatement pstmt, Connection con2) {
		
try {
			
			
			if(pstmt!=null)
			   pstmt.close();
			
			if(con!=null)
			   con.close();
			
		} 
	
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}

