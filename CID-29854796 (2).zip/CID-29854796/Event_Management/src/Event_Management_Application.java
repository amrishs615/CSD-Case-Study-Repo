import java.util.Scanner;

public class Event_Management_Application {

	public static void main(String[] args) {
		
	    Scanner sc=new Scanner(System.in);
	    System.out.println("Enter the operations");
		System.out.println("1.Add a new event");
		System.out.println("2.view event details");
		System.out.println("3.Update event information");
		System.out.println("4.Delete an event");
		
		System.out.println("5.Add a new participant");
		System.out.println("6.view participant details");
		System.out.println("7.Update participant information");
		System.out.println("8.Delete a participant");
		
		System.out.println("9.Register a participant for an event");
		System.out.println("10.View registration details");
		System.out.println("11.Update registration information");
		System.out.println("12.Cancel a registration");
		
		System.out.println("Enter the Operations");
	    int operation=sc.nextInt();
	    switch(operation) {
	    case 1:
	    	Event.addEvent();
	    	break;
	    case 2:
	    	Event.viewDetails();
	    	break;
	    case 3:
	    	Event.updateEventInfo();
	    	break;
	    case 4:
	    	Event.deleteEvent();
	    	break;
	    	
	    case 5:
	    	Participant.addParticipant();
	    	break;
	    case 6:
	    	Participant.viewParticipantDetails();
	    	break;
	    case 7:
	    	Participant.updateParticipantInfo();
	    	break;
	    case 8:
	    	Participant.deleteParticipant();
	    	break;
	    	
	    case 9:
	    	Registration.registerParticipant();
	    	break;
	    case 10:
	    	Registration.viewRegistrationDetails();
	    	break;
	    case 11:
	    	Registration.updateRegistrationInfo();
	    	break;
	    case 12:
	    	Registration.cancelRegistration();
	    	break;
	   
	    }
	}

}
