import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;





public class Event {
	Connection con=null;
	Statement pstmt=null;
	static  int id;
	static  String name;
	static int date;
	static String location;
	static String discription;
	static int capacity;
	/*
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the operations");
		System.out.println("1.Add a new event");
		System.out.println("2.view event details");
		System.out.println("3.Update event information");
		System.out.println("4.Delete an event");
		int operations=sc.nextInt();
		
		switch(operations) {
		
		case 1:
			addEvent();
			break;
		case 2:
			viewDetails();
			break;
		case 3:
			updateEventInfo();
			break;
		case 4:
			deleteEvent();
			break;
		}
		//addEvent();
		//viewDetails();
		//deleteEvent();
		//updateEventInfo();
	}
	*/
	
	
	
	
	/* Add a event*/
	public static void addEvent() {
    
	 
	 /* sc1-->for integer type*/
	 Scanner sc1=new Scanner(System.in);
	 
	 /* sc2-->for String type*/
	 Scanner sc2=new Scanner(System.in);
	 
	 System.out.println("Enter id");
	 id=sc1.nextInt();
	 
	 System.out.println("Enter Name");
	 name=sc2.next();
	 
	 System.out.println("Enter date");
	 date=sc1.nextInt();
	 
	 sc2.nextLine();
	 System.out.println("Enter location");
	 location=sc2.nextLine();
	 
	 System.out.println("Enter discription");
	 discription=sc2.nextLine();
	 
	 System.out.println("Enter capacity");
	 capacity=sc1.nextInt();
	 
	 
	 Connection con=null;
	 PreparedStatement pstmt=null;
	 
	 String q="insert into event_table(event_id,name,date,location,discription,capacity) values(?,?,?,?,?,?)";
	 
	 
	 try {
		con=MyConnect.connect();
		pstmt=con.prepareStatement(q);
		pstmt.setInt(1,id);
		pstmt.setString(2,name);
		pstmt.setInt(3,date);
		pstmt.setString(4,location);
		pstmt.setString(5,discription);
		pstmt.setInt(6,capacity);
		
		int x=pstmt.executeUpdate();
		//System.out.println("Output"+" "+x);
		if(x!=0) {
			System.out.println("Data is inserted");
		}
		else {
			System.out.println("Data is not inserted");
		}
		
		
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	 
	finally {
		
			try {
				MyConnect.close1( pstmt, con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 
	
	}
	 
}
	/*View Event details*/
	
	public static void viewDetails() {
		Connection con=null;
		Statement stmt=null;
		ResultSet res=null;
		
		 try{
			    con= MyConnect.connect();
				stmt=con.createStatement();
				res=stmt.executeQuery("select* from event_table");
				while(res.next()==true) {
				System.out.println(res.getInt(1)+" "+res.getString(2)+" "+
				 res.getDate(3)+" "+res.getString(4)+" "+res.getString(5)+" "+res.getString(6));	
				 }
				/*
				 * to organize the output in correct order
				 * id=res.getInt(1);
				 * name=res.getString(2);
				 * email=res.getString(3);
				 * salary=res.getInt(4);
				 * System.out.printf("%d  %-9s  %-10s  %d\n",id,name,email,salary);
				 */
			 }
			 catch(ClassNotFoundException  | SQLException e ){
			 e.printStackTrace();
			 }
		 finally {
			 
			 MyConnect.close2(res, stmt, con);
		 }
			
		
	}
	
	/*Deleting the event*/
	
	public static void deleteEvent() {
		
		Scanner sc1=new Scanner(System.in);
		
		System.out.println("Enter the id to be deleted");
		id=sc1.nextInt();
		
		 Connection con=null;
		 PreparedStatement pstmt=null;
		 
		 String q="delete from event_table where event_id=?";
		
		 try {
				con=MyConnect.connect();
				pstmt=con.prepareStatement(q);
				pstmt.setInt(1,id);
				
		         
				int x=pstmt.executeUpdate();
				//System.out.println("Output"+" "+x);
				if(x!=0) {
					System.out.println("Data Deleted");
					
				}
				else {
					System.out.println("Failure in deleted");
				}
	        }
		 catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 finally {
			 try {
					MyConnect.close1( pstmt, con);
				} catch (Exception e) { 
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			 
		 }
	
}   
	
	public static void updateEventInfo() {
	
    Scanner sc1=new Scanner(System.in);
    Scanner sc2=new Scanner(System.in);
		
        System.out.println("Enter the data to be updated");
        id=sc1.nextInt();
		System.out.println("Enter the location to be updated");
		location=sc2.nextLine();
		System.out.println("Enter capacity");
		capacity= sc1.nextInt();
		
		
		 Connection con=null;
		 PreparedStatement pstmt=null;
		 
		 String q="update event_table set location=?, capacity=? where event_id=?";
		
		 try {
				con=MyConnect.connect();
				pstmt=con.prepareStatement(q);
				

				pstmt.setInt(2, capacity);
				pstmt.setString(1, location);

				pstmt.setInt(3, id);
				
				
		         
				int x=pstmt.executeUpdate();
				//System.out.println("Output"+" "+x);
				if(x!=0) {
					System.out.println("Data updated");
				}
				else {
					System.out.println("Data is not updated");
				}
	        }
		 catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 finally {
			 try {
					MyConnect.close1( pstmt, con);
				} catch (Exception e) { 
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			 
		 }
	}
}

	


